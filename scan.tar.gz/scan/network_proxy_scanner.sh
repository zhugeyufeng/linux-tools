#!/usr/bin/bash

# 网络代理扫描脚本
# 功能：
# 1. 使用nmap扫描网段找到在线主机
# 2. 使用rustscan扫描开放端口(>5535)
# 3. 使用proxy_check.sh验证代理有效性

# 配置参数
NETWORK_CIDR=""
ONLINE_FILE="online.txt"
PORTS_FILE="ports.txt"
PROXY_CHECK_SCRIPT="./proxy_check.sh"
RUSTSCAN_TIMEOUT=300  # rustscan超时时间（秒）
NMAP_TIMEOUT=600      # nmap超时时间（秒）
PUSH_NUM="15110"
PUSH_KEY="sctp15110ttac7czso1kxbbt8kmg9rat"
PUSH_API_URL="https://${PUSH_NUM}.push.ft07.com/send/${PUSH_KEY}.send"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_info() {
    echo -e "${CYAN}[信息]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[成功]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[警告]${NC} $1"
}

print_error() {
    echo -e "${RED}[错误]${NC} $1"
}

print_step() {
    echo -e "${BLUE}[步骤]${NC} $1"
}

# 发送推送通知
send_push_notification() {
    local title="$1"
    local message="$2"
    
    if ! command -v curl >/dev/null 2>&1; then
        print_warning "curl未安装，无法发送推送通知"
        return 1
    fi
    
    print_info "发送推送通知..."
    
    # 构建POST数据
    local postdata="text=$title&desp=$message"
    
    # 发送请求
    local result
    result=$(curl -X POST \
         -H "Content-type: application/x-www-form-urlencoded" \
         -d "$postdata" \
         -s -o /dev/null -w "%{http_code}" \
         "$PUSH_API_URL")
    
    if [ "$result" = "200" ]; then
        print_success "推送通知发送成功"
    else
        print_warning "推送通知发送失败，HTTP状态码: $result"
    fi
    
    return 0
}

# 显示使用说明
show_usage() {
    echo "网络代理扫描脚本"
    echo "================="
    echo ""
    echo "用法: $0 <网段CIDR>"
    echo ""
    echo "参数:"
    echo "  网段CIDR    要扫描的网段，格式如: 192.168.0.0/16；脚本会自动拆分成/22子网，每3分钟处理一个/22"
    echo ""
    echo "扫描流程:"
    echo "  1. 将输入的/16网段拆分成多个/22子网"
    echo "  2. 对每个/22子网，间隔10分钟进行扫描"
    echo "  3. 将每个/22子网进一步拆分成/24子网进行并行扫描"
    echo "  4. 使用nmap发现在线主机"
    echo "  5. 使用rustscan扫描开放端口(>5535)"
    echo "  6. 使用proxy_check.sh验证代理有效性"
    echo ""
    echo "示例:"
    echo "  $0 192.168.0.0/16"
    echo ""
    echo "输出文件:"
    echo "  online.txt         - 在线主机列表"
    echo "  ports.txt          - 发现的端口列表(IP:Port格式)"
    echo "  valid_proxies.txt  - 有效代理列表"
    echo "  valid_proxies.log  - 详细代理信息"
    echo ""
}

# 检查依赖工具
check_dependencies() {
    print_step "检查依赖工具..."
    
    local missing_tools=()
    
    # 检查nmap
    if ! command -v nmap >/dev/null 2>&1; then
        missing_tools+=("nmap")
    fi
    
    # 检查rustscan
    if ! command -v rustscan >/dev/null 2>&1; then
        missing_tools+=("rustscan")
    fi
    
    # 检查proxy_check.sh
    if [ ! -f "$PROXY_CHECK_SCRIPT" ]; then
        missing_tools+=("proxy_check.sh")
    fi
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        print_error "缺少必需工具: ${missing_tools[*]}"
        echo ""
        echo "安装说明:"
        for tool in "${missing_tools[@]}"; do
            case $tool in
                "nmap")
                    echo "  - nmap: sudo apt-get install nmap"
                    ;;
                "rustscan")
                    echo "  - rustscan: https://github.com/RustScan/RustScan#installation"
                    ;;
                "proxy_check.sh")
                    echo "  - proxy_check.sh: 确保脚本在当前目录中"
                    ;;
            esac
        done
        return 1
    fi
    
    print_success "所有依赖工具检查通过"
    return 0
}

# 自动安装Python依赖
install_python_dependencies() {
    local requirements_file="requirements.txt"

    if [ ! -f "$requirements_file" ]; then
        print_info "未找到requirements.txt，跳过Python依赖安装"
        return 0
    fi

    if [ ! -s "$requirements_file" ]; then
        print_info "requirements.txt为空，跳过Python依赖安装"
        return 0
    fi

    local pip_cmd=""
    if command -v python3 >/dev/null 2>&1; then
        pip_cmd="python3 -m pip"
    elif command -v pip3 >/dev/null 2>&1; then
        pip_cmd="pip3"
    else
        print_warning "未找到python3或pip3，无法自动安装Python依赖"
        return 0
    fi

    print_step "安装Python依赖 ($requirements_file)"
    if $pip_cmd install --upgrade pip >/dev/null 2>&1; then
        print_info "pip已更新"
    fi

    if $pip_cmd install --quiet -r "$requirements_file"; then
        print_success "Python依赖安装完成"
    else
        print_warning "自动安装Python依赖失败，请手动检查"
        return 1
    fi

    return 0
}

# 检查sudo权限
check_sudo() {
    print_step "检查sudo权限..."
    
    if ! sudo -n true 2>/dev/null; then
        print_warning "需要sudo权限来运行nmap和rustscan"
        print_info "请输入sudo密码："
        sudo true || {
            print_error "无法获取sudo权限"
            return 1
        }
    fi
    
    print_success "sudo权限检查通过"
    return 0
}

# 验证网段格式
validate_cidr() {
    local cidr="$1"
    
    # 简单的CIDR格式验证
    if [[ ! "$cidr" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$ ]]; then
        print_error "无效的CIDR格式: $cidr"
        print_info "正确格式示例: 192.168.1.0/24"
        return 1
    fi
    
    return 0
}

# 将CIDR拆分成/22网段（使用Python辅助计算）
split_cidr_to_22() {
    local cidr="$1"
    local prefix=$(echo "$cidr" | cut -d'/' -f2)
    
    # 如果已经是/22或更小，直接返回
    if [ "$prefix" -ge 22 ]; then
        echo "$cidr"
        return 0
    fi
    
    # 对于太大的网段，给出警告
    if [ "$prefix" -lt 16 ]; then
        print_warning "网段 $cidr 太大，包含 $((2 ** (22 - prefix))) 个/22子网"
        print_warning "建议使用/16或更大的网段"
    fi
    
    # 使用Python进行精确的网络计算
    local python_result
    python_result=$(python3 -c "
import ipaddress
import sys

try:
    network = ipaddress.IPv4Network('$cidr', strict=False)
    subnets = list(network.subnets(new_prefix=22))
    for subnet in subnets:
        print(subnet)
except Exception as e:
    sys.exit(1)
" 2>/dev/null)
    
    local python_exit_code=$?
    
    if [ "$python_exit_code" -eq 0 ] && [ -n "$python_result" ]; then
        echo "$python_result"
        return 0
    fi
    
    # Python不可用时的备选方案 - 使用简化的bash计算
    print_warning "Python不可用，使用简化计算方法"
    
    local base_ip=$(echo "$cidr" | cut -d'/' -f1)
    local ip_parts=($(echo "$base_ip" | tr '.' ' '))
    
    # 对于/16网段的简化处理，拆分成/22
    if [ "$prefix" -eq 16 ]; then
        for ((i=0; i<64; i++)); do  # 2^(22-16) = 64
            local third_octet=$(( (i * 4) % 256 ))
            local second_octet_add=$(( i * 4 / 256 ))
            echo "${ip_parts[0]}.$((ip_parts[1] + second_octet_add)).$third_octet.0/22"
        done
    else
        print_warning "无法精确拆分网段 $cidr，使用原始网段进行扫描"
        echo "$cidr"
    fi
}

# 将CIDR拆分成/24网段（使用Python辅助计算）
split_cidr_to_24() {
    local cidr="$1"
    local prefix=$(echo "$cidr" | cut -d'/' -f2)
    
    # 如果已经是/24或更小，直接返回
    if [ "$prefix" -ge 24 ]; then
        echo "$cidr"
        return 0
    fi
    
    # 对于太大的网段，给出警告并建议使用更小的网段
    if [ "$prefix" -lt 22 ]; then
        print_warning "网段 $cidr 太大，包含 $((2 ** (24 - prefix))) 个/24子网"
        print_warning "这可能导致扫描时间过长，建议使用更小的网段（如/22或更大）"
        print_info "自动继续执行扫描..."
    fi
    
    # 首先尝试使用Python进行精确的网络计算
    local python_result
    python_result=$(python3 -c "
import ipaddress
import sys

try:
    network = ipaddress.IPv4Network('$cidr', strict=False)
    subnets = list(network.subnets(new_prefix=24))
    print(f'Python: {len(subnets)} 个/24子网', file=sys.stderr)
    for subnet in subnets:
        print(subnet)
except Exception as e:
    print(f'Python错误: {e}', file=sys.stderr)
    sys.exit(1)
" 2>/dev/null)
    
    local python_exit_code=$?
    
    if [ "$python_exit_code" -eq 0 ] && [ -n "$python_result" ]; then
        local python_count=$(echo "$python_result" | wc -l)
        print_info "Python成功拆分出 $python_count 个/24子网"
        echo "$python_result"
        return 0
    fi
    
    # Python不可用时的备选方案 - 使用简化的bash计算
    print_warning "Python不可用，使用简化计算方法"
    
    local base_ip=$(echo "$cidr" | cut -d'/' -f1)
    local ip_parts=($(echo "$base_ip" | tr '.' ' '))
    local subnet_count=$((2 ** (24 - prefix)))
    
    # 对于/22网段的简化处理
    if [ "$prefix" -eq 22 ]; then
        print_info "拆分/22网段 $cidr 为4个/24子网..."
        for ((i=0; i<4; i++)); do  # /22包含4个/24子网
            local third_octet=$((ip_parts[2] + i))
            echo "${ip_parts[0]}.${ip_parts[1]}.$third_octet.0/24"
        done
    # 对于/16网段的简化处理
    elif [ "$prefix" -eq 16 ]; then
        for ((i=0; i<256; i++)); do
            echo "${ip_parts[0]}.${ip_parts[1]}.$i.0/24"
        done
    # 对于/20网段的简化处理  
    elif [ "$prefix" -eq 20 ]; then
        local base_third_octet=${ip_parts[2]}
        local masked_third=$((base_third_octet & 240))  # 240 = 11110000
        for ((i=0; i<16; i++)); do
            echo "${ip_parts[0]}.${ip_parts[1]}.$((masked_third + i)).0/24"
        done
    # 对于其他情况，返回原始CIDR
    else
        print_warning "无法精确拆分网段 $cidr，使用原始网段进行扫描"
        echo "$cidr"
    fi
}

# 并行扫描单个/24网段的函数
scan_single_subnet() {
    local subnet="$1"
    local subnet_index="$2"
    local total_subnets="$3"
    local temp_file="$4"
    
    print_info "[$subnet_index/$total_subnets] 扫描子网: $subnet"
    
    # 使用优化的nmap参数扫描（保留所有现有参数）
    local nmap_output
    nmap_output=$(sudo timeout "$NMAP_TIMEOUT" nmap -sn -PE -PP -PM -n --min-rate 300 --max-retries 1 --host-timeout 3s -T4 "$subnet" -oG - 2>/dev/null)
    local nmap_exit_code=$?
    
    if [ "$nmap_exit_code" -eq 124 ]; then
        print_warning "  $subnet: nmap扫描超时"
        return 1
    elif [ "$nmap_exit_code" -ne 0 ]; then
        print_warning "  $subnet: nmap扫描失败，退出码: $nmap_exit_code"
        return 1
    fi
    
    # 提取在线主机IP地址并写入临时文件
    local subnet_ips
    subnet_ips=$(echo "$nmap_output" | grep -oP 'Host: \K[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(?=.*Status: Up)')
    
    if [ -n "$subnet_ips" ]; then
        local subnet_count_ips
        subnet_count_ips=$(echo "$subnet_ips" | wc -l)
        # 确保临时文件目录存在
        mkdir -p "$(dirname "$temp_file")" 2>/dev/null
        echo "$subnet_ips" > "$temp_file" || {
            print_warning "  $subnet: 无法写入临时文件 $temp_file"
            return 1
        }
        print_success "  $subnet: 发现 $subnet_count_ips 个在线主机"
        return 0
    else
        print_info "  $subnet: 无在线主机"
        # 确保临时文件目录存在并创建空文件标记完成
        mkdir -p "$(dirname "$temp_file")" 2>/dev/null
        touch "$temp_file" || {
            print_warning "  $subnet: 无法创建临时文件 $temp_file"
            return 1
        }
        return 0
    fi
}

# 使用nmap扫描在线主机（支持并行扫描）
# 使用nmap扫描在线主机（每个/22独立验证）
scan_online_hosts() {
    local cidr="$1"
    print_step "使用nmap扫描在线主机: $cidr"
    
    # 将CIDR拆分成/22网段
    local subnets_22
    subnets_22=$(split_cidr_to_22 "$cidr")
    local subnet_22_count=$(echo "$subnets_22" | wc -l)
    
    print_info "网段拆分为 $subnet_22_count 个/22子网，每个子网独立验证代理"
    
    local current_subnet_22=0
    local total_hosts_all=0
    local total_ports_all=0
    local total_valid_all=0
    
    # 对每个/22子网进行独立处理
    while read -r subnet_22; do
        ((current_subnet_22++))
        print_info "处理第 $current_subnet_22/$subnet_22_count 个/22子网: $subnet_22"
        
        # 如果不是第一个/22，等待3分钟（显示倒计时）
        if [ "$current_subnet_22" -gt 1 ]; then
            print_info "等待10分钟后继续下一个/22子网..."
            local remaining=600  # 10分钟 = 600秒
            while [ $remaining -gt 0 ]; do
                local minutes=$((remaining / 60))
                local seconds=$((remaining % 60))
                printf "\r[CYAN][信息][NC] 剩余时间: %02d:%02d" $minutes $seconds
                sleep 1
                ((remaining--))
            done
            printf "\r[CYAN][信息][NC] 等待完成，继续扫描...\n"
        fi
        
        # 创建临时文件用于当前/22子网
        local temp_dir="/tmp/nmap_scan_$$/subnet_22_$current_subnet_22"
        mkdir -p "$temp_dir" || {
            print_error "无法创建临时目录: $temp_dir"
            continue
        }
        
        local subnet_hosts_file="$temp_dir/hosts.txt"
        local subnet_ports_file="$temp_dir/ports.txt"
        > "$subnet_hosts_file"
        > "$subnet_ports_file"
        
        # 将/22拆分成/24网段
        local subnets_24
        subnets_24=$(split_cidr_to_24 "$subnet_22")
        local subnet_24_count=$(echo "$subnets_24" | wc -l)
        
        print_info "  $subnet_22 拆分为 $subnet_24_count 个/24子网进行扫描"
        print_info "  使用优化的nmap参数进行快速扫描..."
        print_info "  启用并行扫描模式（最多同时4个进程）..."
        
        local current_subnet_24=0
        local max_parallel=4
        local running_jobs=0
        
        # 将所有/24子网存储到数组中
        local subnet_24_array=()
        while read -r subnet_24; do
            subnet_24_array+=("$subnet_24")
        done <<< "$subnets_24"
        
        # 并行扫描所有/24子网
        local pids=()  # 存储进程ID
        for subnet_24 in "${subnet_24_array[@]}"; do
            ((current_subnet_24++))
            
            # 等待可用的进程槽
            while [ $running_jobs -ge $max_parallel ]; do
                # 检查并清理已完成的进程
                local new_pids=()
                for pid in "${pids[@]}"; do
                    if kill -0 "$pid" 2>/dev/null; then
                        new_pids+=("$pid")
                    else
                        ((running_jobs--))
                    fi
                done
                pids=("${new_pids[@]}")
                
                # 如果还是满载，稍等片刻
                if [ $running_jobs -ge $max_parallel ]; then
                    sleep 0.1
                fi
            done
            
            # 启动新的扫描进程
            local temp_file="$temp_dir/subnet_$current_subnet_24.txt"
            scan_single_subnet "$subnet_24" "$current_subnet_24" "$subnet_24_count" "$temp_file" &
            pids+=($!)
            ((running_jobs++))
        done
        
        # 等待当前/22的所有/24扫描完成
        print_info "  等待 $subnet_22 的所有/24扫描完成..."
        wait
        
        # 收集当前/22的主机结果
        print_info "  收集 $subnet_22 的主机扫描结果..."
        for ((i=1; i<=subnet_24_count; i++)); do
            local temp_file="$temp_dir/subnet_$i.txt"
            if [ -f "$temp_file" ] && [ -s "$temp_file" ]; then
                cat "$temp_file" >> "$subnet_hosts_file"
            fi
        done
        
        local subnet_hosts_count=$(wc -l < "$subnet_hosts_file" 2>/dev/null || echo 0)
        if [ "$subnet_hosts_count" -gt 0 ]; then
            print_success "  $subnet_22: 发现 $subnet_hosts_count 个在线主机"
            # 将当前/22的主机追加到全局主机文件
            cat "$subnet_hosts_file" >> "$ONLINE_FILE"
            ((total_hosts_all += subnet_hosts_count))
        else
            print_info "  $subnet_22: 无在线主机"
            # 清理临时目录并继续下一个
            rm -rf "$temp_dir" 2>/dev/null
            continue
        fi
        
        # 对当前/22的主机进行端口扫描
        print_info "  开始对 $subnet_22 的主机进行端口扫描..."
        if scan_ports_for_subnet "$subnet_hosts_file" "$subnet_ports_file"; then
            local subnet_ports_count=$(wc -l < "$subnet_ports_file" 2>/dev/null || echo 0)
            if [ "$subnet_ports_count" -gt 0 ]; then
                print_success "  $subnet_22: 发现 $subnet_ports_count 个开放端口"
                # 将当前/22的端口追加到全局端口文件
                cat "$subnet_ports_file" >> "$PORTS_FILE"
                ((total_ports_all += subnet_ports_count))
                
                # 对当前/22的端口进行代理验证
                print_info "  开始对 $subnet_22 的端口进行代理验证..."
                if verify_proxies_for_subnet "$subnet_ports_file"; then
                    local subnet_valid_count=0
                    if [ -s "valid_proxies.txt" ]; then
                        subnet_valid_count=$(wc -l < "valid_proxies.txt")
                        ((subnet_valid_count -= total_valid_all))  # 计算当前/22新增的有效代理数
                        ((total_valid_all += subnet_valid_count))
                    fi
                    if [ "$subnet_valid_count" -gt 0 ]; then
                        print_success "  $subnet_22: 发现 $subnet_valid_count 个有效代理"
                        # 发送推送通知
                        local push_title="发现有效代理 - 子网: $subnet_22"
                        local push_message="新增代理数量: $subnet_valid_count
当前总代理数: $total_valid_all

新增代理列表:
$(tail -n $subnet_valid_count valid_proxies.txt | sed 's/^/- /')"
                        send_push_notification "$push_title" "$push_message"
                    else
                        print_info "  $subnet_22: 未发现有效代理"
                    fi
                else
                    print_warning "  $subnet_22: 代理验证失败"
                fi
            else
                print_info "  $subnet_22: 未发现开放端口"
            fi
        else
            print_warning "  $subnet_22: 端口扫描失败"
        fi
        
        # 清理当前/22的临时目录
        if [ -d "$temp_dir" ]; then
            rm -rf "$temp_dir" 2>/dev/null || print_warning "无法清理临时目录: $temp_dir"
        fi
        
        echo ""
        
    done <<< "$subnets_22"
    
    if [ "$total_hosts_all" -eq 0 ]; then
        print_warning "所有/22子网均未发现在线主机"
        rm -rf "/tmp/nmap_scan_$$" 2>/dev/null
        return 1
    fi
    
    print_success "所有/22子网扫描完成"
    print_info "累计发现在线主机: $total_hosts_all 个"
    print_info "累计发现开放端口: $total_ports_all 个"
    print_info "累计验证有效代理: $total_valid_all 个"
    
    # 清理主临时目录
    if [ -d "/tmp/nmap_scan_$$" ]; then
        rm -rf "/tmp/nmap_scan_$$" 2>/dev/null || print_warning "无法清理临时目录: /tmp/nmap_scan_$$"
    fi
    
    return 0
}

# 使用rustscan扫描端口（针对特定主机文件）
scan_ports_for_subnet() {
    local hosts_file="$1"
    local ports_file="$2"
    
    if [ ! -s "$hosts_file" ]; then
        return 1
    fi
    
    # 清空端口文件
    > "$ports_file"
    
    local total_hosts=$(wc -l < "$hosts_file")
    local current_host=0
    local total_ports=0
    
    print_info "开始对 $total_hosts 个主机进行端口扫描..."
    
    while read -r ip; do
        ((current_host++))
        print_info "  [$current_host/$total_hosts] 扫描主机: $ip"
        
        # 使用rustscan扫描端口
        local rustscan_output
        rustscan_output=$(sudo timeout "$RUSTSCAN_TIMEOUT" rustscan -a "$ip" --range 5536-65535 -t 500 -b 2000 --scan-order "Random" --greppable 2>/dev/null)
        local rustscan_exit_code=$?
        
        if [ "$rustscan_exit_code" -eq 124 ]; then
            continue
        elif [ "$rustscan_exit_code" -ne 0 ]; then
            continue
        fi
        
        # 解析rustscan输出
        local ports
        ports=$(echo "$rustscan_output" | grep -oP "$ip"' -> \[\K[0-9,]+(?=\])' | tr ',' '\n')
        
        if [ -n "$ports" ]; then
            local host_port_count=0
            while read -r port; do
                if [ -n "$port" ] && [ "$port" -gt 1000 ] 2>/dev/null; then
                    echo "$ip:$port" >> "$ports_file"
                    ((host_port_count++))
                    ((total_ports++))
                fi
            done <<< "$ports"
            
            if [ "$host_port_count" -gt 0 ]; then
                print_success "    $ip: 发现 $host_port_count 个开放端口"
            fi
        else
            print_info "    $ip: 未发现开放端口"
        fi
        
    done < "$hosts_file"
    
    if [ "$total_ports" -gt 0 ]; then
        print_success "端口扫描完成，发现 $total_ports 个开放端口"
    else
        print_info "未发现开放端口"
    fi
    
    return 0
}

# 验证代理有效性（针对特定端口文件）
verify_proxies_for_subnet() {
    local ports_file="$1"
    
    if [ ! -s "$ports_file" ]; then
        return 1
    fi
    
    if [ ! -x "$PROXY_CHECK_SCRIPT" ]; then
        print_warning "proxy_check.sh不可执行，尝试添加执行权限..."
        chmod +x "$PROXY_CHECK_SCRIPT" 2>/dev/null || {
            return 1
        }
    fi
    
    # 设置环境变量指向特定的端口文件，并启用追加模式
    export PROXY_INPUT_FILE="$ports_file"
    export APPEND_MODE=1
    
    # 运行proxy_check.sh（结果会追加到全局的valid_proxies.txt中）
    print_info "正在验证代理有效性，这可能需要一些时间..."
    bash "$PROXY_CHECK_SCRIPT"
    local proxy_check_exit_code=$?
    
    # 清理环境变量
    unset PROXY_INPUT_FILE
    unset APPEND_MODE
    
    if [ "$proxy_check_exit_code" -eq 0 ]; then
        return 0
    else
        return 1
    fi
}

# 验证代理有效性
verify_proxies() {
    print_step "验证代理有效性"
    
    if [ ! -s "$PORTS_FILE" ]; then
        print_error "端口文件为空: $PORTS_FILE"
        return 1
    fi
    
    if [ ! -x "$PROXY_CHECK_SCRIPT" ]; then
        print_warning "proxy_check.sh不可执行，尝试添加执行权限..."
        chmod +x "$PROXY_CHECK_SCRIPT" 2>/dev/null || {
            print_error "无法为proxy_check.sh添加执行权限"
            return 1
        }
    fi
    
    print_info "开始验证代理有效性..."
    print_info "这可能需要较长时间，请耐心等待..."
    
    # 运行proxy_check.sh
    bash "$PROXY_CHECK_SCRIPT"
    local proxy_check_exit_code=$?
    
    if [ "$proxy_check_exit_code" -eq 0 ]; then
        print_success "代理验证完成"
        
        # 检查结果
        if [ -s "valid_proxies.txt" ]; then
            local valid_count=$(wc -l < "valid_proxies.txt")
            print_success "发现 $valid_count 个有效代理"
            print_info "有效代理列表: valid_proxies.txt"
            print_info "详细代理信息: valid_proxies.log"
        else
            print_warning "未发现有效代理"
        fi
    else
        print_error "代理验证失败，退出码: $proxy_check_exit_code"
        return 1
    fi
    
    return 0
}

# 清理函数
cleanup() {
    print_info "清理临时文件..."
    # 这里可以添加清理临时文件的代码
}

# 主函数
main() {
    # 显示脚本标题
    echo "========================================"
    echo "      网络代理扫描脚本 v1.0"
    echo "========================================"
    echo ""
    
    # 检查参数
    if [ $# -ne 1 ]; then
        show_usage
        exit 1
    fi
    
    # 设置清理陷阱
    trap cleanup EXIT
    
    print_info "本次任务网段: $1"
    print_info "输出文件将保存在当前目录"
    echo ""
    
    # 检查依赖
    if ! check_dependencies; then
        exit 1
    fi
    echo ""
    
    if ! install_python_dependencies; then
        print_warning "Python依赖安装可能失败，请手动检查环境"
    fi
    echo ""

    # 检查sudo权限
    if ! check_sudo; then
        exit 1
    fi
    echo ""
    
    # 清空输出文件
    > "$ONLINE_FILE"
    > "$PORTS_FILE"
    > "valid_proxies.txt"
    > "valid_proxies.log"

    NETWORK_CIDR="$1"
    echo "----------------------------------------"
    print_info "处理网段: $NETWORK_CIDR"
    
    # 验证CIDR格式
    if ! validate_cidr "$NETWORK_CIDR"; then
        print_error "无效的网段格式: $NETWORK_CIDR"
        exit 1
    fi
    
    # 检查是否为/16网段
    local prefix=$(echo "$NETWORK_CIDR" | cut -d'/' -f2)
    if [ "$prefix" -ne 16 ]; then
        print_warning "建议使用/16网段，当前为/$prefix"
        print_info "脚本会自动处理，但可能需要较长时间"
    fi
    
    # 第1步：扫描在线主机（包含端口扫描和代理验证）
    if ! scan_online_hosts "$NETWORK_CIDR"; then
        print_error "网段 $NETWORK_CIDR 扫描失败"
        exit 1
    fi
    echo ""
    
    local total_hosts=$(wc -l < "$ONLINE_FILE")
    local total_ports=$(wc -l < "$PORTS_FILE")
    local total_valid=0
    if [ -s "valid_proxies.txt" ]; then
        total_valid=$(wc -l < "valid_proxies.txt")
    fi
    
    print_success "所有扫描任务完成！"
    print_info "累计发现在线主机: $total_hosts 个"
    print_info "累计发现开放端口: $total_ports 个"
    print_info "累计验证有效代理: $total_valid 个"
    echo ""
    
    # 显示所有有效代理
    if [ "$total_valid" -gt 0 ]; then
        print_info "有效代理列表:"
        cat "valid_proxies.txt" | while read -r proxy; do
            echo "  - $proxy"
        done
        echo ""
        
        # 发送总结推送通知
        local summary_title="扫描任务完成 - 网段: $NETWORK_CIDR"
        local summary_message="总在线主机: $total_hosts 个
总开放端口: $total_ports 个
总有效代理: $total_valid 个

有效代理列表:
$(cat valid_proxies.txt | sed 's/^/- /')"
        send_push_notification "$summary_title" "$summary_message"
    fi
    
    echo "生成的文件:"
    echo "  - $ONLINE_FILE: 在线主机列表"
    echo "  - $PORTS_FILE: 开放端口列表"
    echo "  - valid_proxies.txt: 有效代理列表"
    echo "  - valid_proxies.log: 详细代理信息"
    echo ""
}

# 运行主函数
main "$@"